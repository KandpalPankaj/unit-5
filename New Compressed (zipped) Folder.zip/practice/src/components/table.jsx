import { useEffect, useState } from "react";


export const Table=()=>{
    const [table, setTable] = useState([]);
useEffect(()=>{
    async function getData() {
        let res = await fetch("http://localhost:8080/houses");
        let data = await res.json();
        setTable(data);
        
      }
      getData();
},[])
    
      
    return (
        <div>
        <table border="1">
          <thead>
            <tr>
              <th>Name</th>
              <th>Owner name</th>
              <th>Address</th>
              <th>Area Code</th>
              <th>Rent</th>
              <th>Preferred</th>
            </tr>
          </thead>
          {table.map((el) => (
            <tbody>
              <tr>
                <td>{el.name}</td>
                <td>{el.owner}</td>
                <td>{el.Address}</td>
                <td>{el.areaCode}</td>
                <td>{el.rent}</td>
                <td>{el.preferred}</td>
              </tr>
            </tbody>
          ))}
        </table>
        </div>
    )
}